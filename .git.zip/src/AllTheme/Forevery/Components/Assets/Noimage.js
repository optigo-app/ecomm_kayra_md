import Noimage from './image-not-found.jpg';
export const NoImage = Noimage ;