import React from 'react'
import './RingPage.scss';

const RingPage = () => {
  return (
    <div className='for_RingPage'>RingPage</div>
  )
}

export default RingPage